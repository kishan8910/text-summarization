__version__ = '0.0.1'

from .summarize import Summary, summarize_blocks, summarize_page, summarize_text