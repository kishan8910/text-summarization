text-summarizer
===============

Django app which can summarize text content(articles) and also perform live comment summary. #WIP 